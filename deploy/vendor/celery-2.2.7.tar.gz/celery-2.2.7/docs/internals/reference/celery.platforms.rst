======================================
 celery.platforms
======================================

.. contents::
    :local:
.. currentmodule:: celery.platforms

.. automodule:: celery.platforms
    :members:
    :undoc-members:

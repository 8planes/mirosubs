=====================================================
 celery.utils.term
=====================================================

.. contents::
    :local:
.. currentmodule:: celery.utils.term

.. automodule:: celery.utils.term
    :members:
    :undoc-members:

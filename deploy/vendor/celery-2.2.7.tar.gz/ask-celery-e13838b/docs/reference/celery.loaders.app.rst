=================================
 celery.loaders.app
=================================

.. contents::
    :local:
.. currentmodule:: celery.loaders.app

.. automodule:: celery.loaders.app
    :members:
    :undoc-members:

============================================
 celery.utils.compat
============================================

.. contents::
    :local:
.. currentmodule:: celery.utils.compat

.. automodule:: celery.utils.compat
    :members:
    :undoc-members:

================================
 celery.registry
================================

.. contents::
    :local:
.. currentmodule:: celery.registry

.. automodule:: celery.registry
    :members:
    :undoc-members:

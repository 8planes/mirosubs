==========================================================
 celery.utils.dispatch.saferef
==========================================================

.. contents::
    :local:
.. currentmodule:: celery.utils.dispatch.saferef

.. automodule:: celery.utils.dispatch.saferef
    :members:
    :undoc-members:

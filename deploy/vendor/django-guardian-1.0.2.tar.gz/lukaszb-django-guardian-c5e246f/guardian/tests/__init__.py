from admin_test import *
from core_test import *
from custompkmodel_test import *
from decorators_test import *
from forms_test import *
from orphans_test import *
from other_test import *
from utils_test import *
from shortcuts_test import *
from tags_test import *



def post_detail(request):
    return


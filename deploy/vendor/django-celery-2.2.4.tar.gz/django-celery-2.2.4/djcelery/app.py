from celery.app import default_app


#: The Django-Celery app instance.
app = default_app

==============================
 Managers - djcelery.managers
==============================

.. contents::
    :local:
.. currentmodule:: djcelery.managers

.. automodule:: djcelery.managers
    :members:
    :undoc-members:

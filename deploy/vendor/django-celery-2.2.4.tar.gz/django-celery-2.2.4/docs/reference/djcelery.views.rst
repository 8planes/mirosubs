========================
 Views - djcelery.views
========================

.. contents::
    :local:
.. currentmodule:: djcelery.views

.. automodule:: djcelery.views
    :members:
    :undoc-members:

About
-----

Django-keyedcache provides a simplified, speedy way to manage caching in Django apps.

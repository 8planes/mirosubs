Requirements
============

Django-Livesettings requires only the module `Django-Keyedcache` to work.

.. _`Django-Keyedcache`: http://bitbucket.org/bkroeze/django-keyedcache/

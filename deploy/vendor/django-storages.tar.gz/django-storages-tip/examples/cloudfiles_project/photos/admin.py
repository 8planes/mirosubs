from django.contrib import admin
from cloudfiles_project.photos.models import Photo

admin.site.register(Photo)